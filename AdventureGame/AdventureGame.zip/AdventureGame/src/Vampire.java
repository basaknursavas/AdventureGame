public class Vampire extends Obstacle{
    public Vampire() {
        super("Vampire",2,4,14,7);
    }
}
