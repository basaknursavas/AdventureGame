public class Zombie extends Obstacle{
    public Zombie() {
        super("Zombie",1,3,10,4);
    }
}
